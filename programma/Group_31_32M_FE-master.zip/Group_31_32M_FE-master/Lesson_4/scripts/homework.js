// 1. Напишите функцию, которая принимает в качестве аргумента строку, а возвращает ее длину. Выведите результат в консоль.

function getLength(string) {
  return string.length
};

let getLength1 = string => string.length;


// 2. Напишите функцию, которая принимает два аргумента (основание степени и саму степень) и возвращает число в указанной степени. Значение степени должно быть указано по умолчанию 2.

function getExp(num1, num2 = 2) {
  return num1 ** num2 // return Math.pow(num1, num2)
}

let getExp1 = (num1, num2 = 2) => num1 ** num2; // Math.pow(num1, num2)

// console.log(getExp1(2, 3)); // 8
// console.log(getExp1(2)); // 4


// 3. Напишите функцию, которая принимает два аргумента с числовым значением и возвращает большее значение. Выведите результат в консоль. Предложите два варианта решения (через условный оператор и Math.max()).

function getMaxNum(num1, num2) {
  return Math.max(num1, num2)
}

let getMaxNum2 = (a, b) => Math.max(a, b);


function getMaxNum1(num1, num2) {
  if(num1 > num2){
    return num1
  } else {
    return num2
  }
}

let getMaxNum3 = (num1, num2) => {
  if(num1 > num2){
    return num1
  } else {
    return num2
  }
}


// 4. Напишите функцию, принимающую в качестве аргументов три числа и выводящую в консоль отсортированные числа по убыванию. Используйте условный оператор.

function sortNums(num1, num2, num3) {
  if(num1 > num2 && num1 > num3){
    if(num2 > num3){
      console.log(num1, num2, num3)
    } else {
      console.log(num1, num3, num2)
    }
  } else if (num2 > num1 && num2 > num3) {
    if(num1 > num3) {
      console.log(num2, num1, num3)
    } else {
      console.log(num2, num3, num1)
    }
  } else {
    if(num1 > num2) {
      console.log(num3, num1, num2)
    } else {
      console.log(num3, num2, num1)
    }
  }
};

// sortNums(3, 8, 2); // 8, 3, 2
// sortNums(-3, 88, 12); // 88, 12, -3

let sortNums1 = (num1, num2, num3) => {
  if(num1 > num2 && num1 > num3){
    if(num2 > num3){
      console.log(num1, num2, num3)
    } else {
      console.log(num1, num3, num2)
    }
  } else if (num2 > num1 && num2 > num3) {
    if(num1 > num3) {
      console.log(num2, num1, num3)
    } else {
      console.log(num2, num3, num1)
    }
  } else {
    if(num1 > num2) {
      console.log(num3, num1, num2)
    } else {
      console.log(num3, num2, num1)
    }
  }
};
