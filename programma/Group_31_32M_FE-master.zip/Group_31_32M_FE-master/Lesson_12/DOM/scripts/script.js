// DOM - Document Object Model

const header = document.querySelector('.header'); // ищу элемент в html документе

const paragraph = document.querySelector('#par');
const container = document.querySelector('.container');

// console.log(header);
// console.log(paragraph);

header.style.color = 'red';
paragraph.style.backgroundColor = 'green';

header.classList.add('class2');
header.classList.remove('class1');


const text = document.createElement('p'); // создаю новый элемент
text.innerText = 'Какой-то текст'; // добавляем текст в р

const divElem = document.createElement('div');
divElem.innerText = 'Текст внутри нового div';

container.append(text, divElem); //добавляю p внутрь container
