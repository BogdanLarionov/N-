// alert('hello');

// const firstName = prompt('What is your name?');
// const lastName = prompt('What is your last name?');
// const age = prompt('What is you age?');

// if(age < 18) {
//   console.log(`Hi, ${firstName} ${lastName}. Your age is ${age}`);
// } else if (age > 18) {
//   console.log(`Hello, ${firstName} ${lastName}.`);
// } else {
//   console.log(`Dear, ${firstName} ${lastName}. Your age is ${age}`);
// }


// Сгенерируйте случайное число от 0 до 1. Округлите его до одного знака после точки, тип выводимых данных должен быть number. 
// Напишите условный оператор. Если случайное число больше 0.5, то выводить в консоль сообщение "Победа". Если случайное число меньше 0.5, то выводить в консоль сообщение "Поражение". Если случайное число равно 0.5, то выводить в консоль сообщение "Ничья".

let random = +Math.random().toFixed(1);

console.log(random);

if (random > 0.5) {
  console.log('Победа');
} else if (random < 0.5) {
  console.log('Поражение');
} else {
  console.log('Ничья');
};


// Math.random(): 
// Math - объект
// .random() - метод

// let text = 'Nelli';
// text.length: length - свойство


