// 1. Создайте переменную user и присвойте ей значение: '   Ivan Ivanov    '. Выведите переменную user в консоль, но без лишних пробелов по краям.

let user = '   Ivan Ivanov    ';
// console.log(user.trim());


// 2. Напишите программу, которая выводит в консоль рандомное/случайное число от 0 до 1 и округляет его до третьего знака после точки. Воспользуйтесь методом toFixed().

let random = Math.random(); // от 0 до 1
let random_fixed = +random.toFixed(3); //метод .toFixed() возвращает строку

// console.log(random);
// console.log(random_fixed);
// console.log(typeof random_fixed);


// 3. Выведите на экран первую и последнюю буквы предложения, записанного в константу text (текст строки произвольный), в следующем формате:
// First: <первая буква строки>
// Last: <последняя буква строки></последняя>

const text = 'Hello, world!';

let result = `First: <${text[0]}>\nLast: <${text[text.length - 1]}>`;

console.log(result);
