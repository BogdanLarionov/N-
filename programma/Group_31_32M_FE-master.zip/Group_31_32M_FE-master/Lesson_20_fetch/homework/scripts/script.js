const tasks_container = document.querySelector('#tasks_container');

fetch('https://jsonplaceholder.typicode.com/todos')
  .then(resp => resp.json())
  .then(json => render(json))

  const render = (json) => { 
    const tasks = json.map(({ title, completed }) => {
      const task = document.createElement('div');
      const taskTitle = document.createElement('p');
      const taskStatus = document.createElement('p');

      const status = completed ? 'done' : 'not done';
      const background = completed ? 'lightgreen' : 'lightgray';

      taskTitle.innerText = `Task: ${title}`;
      taskStatus.innerText = `Status: ${status}`;

      task.classList.add('task_card');
      task.style.backgroundColor = background;

      task.append(taskTitle, taskStatus);
      return task
    })
    tasks_container.append(...tasks)
  }

