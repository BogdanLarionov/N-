// В файле html в тэге body есть один элемент div с классом root.
// Используя JS (DOM), создать карточку товара (div), которая должна включать в себя следующие данные: Артикул, наименование товара, цена. Данные взять произвольные.
// Применить стили к карточке: width, background-color, border, border-radius, padding, margin.

const rootElem = document.querySelector('.root');

const card = document.createElement('div');
const art = document.createElement('p');
const title = document.createElement('p');
const price = document.createElement('p');

art.innerText = `Articul: 1234`;
title.innerText = 'Title: iPhone 13 Pro';
price.innerText = 'Price: 1300$';

// card.innerHTML = '<p>hello</p>';

card.classList.add('card');

card.append(art, title, price);
rootElem.append(card);
