export const words = [
  {
    id: 1,
    eng: 'Table',
    rus: 'Стол',
    lang: 'eng'
  },
  {
    id: 2,
    eng: 'Head',
    rus: 'Голова',
    lang: 'rus'
  },
  {
    id: 3,
    eng: 'Rain',
    rus: 'Дождь',
    lang: 'eng'
  }
]
