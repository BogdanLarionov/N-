const formElem = document.querySelector('.form');
const cardsContainer = document.querySelector('.cards_container');

formElem.addEventListener('submit', (event) => {
  event.preventDefault(); // запрещает обновлять страницу после отправки формы

  const card = document.createElement('div');
  const nameElem = document.createElement('p');
  const ageElem = document.createElement('p');
  const cityElem = document.createElement('p');

  const { name, age, city } = event.target; // this

  // const name = event.target.name;
  // const age = event.target.age;
  // const city = event.target.city;

  nameElem.innerText = `Name: ${name.value}`;
  ageElem.innerText = `Age: ${age.value}`;
  cityElem.innerText = `City: ${city.value}`;

  card.classList.add('card');

  card.append(nameElem, ageElem, cityElem);
  cardsContainer.append(card);

  name.value = '';
  age.value = '';
  city.value = '';
})
