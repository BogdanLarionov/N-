import React from 'react'
import s from './index.module.css'

export default function Footer() {
  return (
    <footer className={s.footer}>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum natus, vel fuga ex, architecto rerum incidunt reprehenderit maiores quo alias quaerat! Sunt recusandae voluptates, beatae excepturi veniam aliquid ut repellendus?
    </footer>
  )
}
