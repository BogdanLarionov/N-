// Напишите цикл for, который выводить в консоль числа от 1 до 10

// for(let i = 1; i <= 10; i++){
//   console.log(i)
// }

// i = i + 1
// i += 1
// i++

// выражение 1 - начальное значение счетчика
// выражение 2 - условие повторения цикла
// выражение 3 - изменение счетчика


// Напишите цикл for, который выводить в консоль числа от 15 до 65 с шагом 5 
// => 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65

// for(let i = 15; i <= 65; i += 5){
//   console.log(i)
// }


// Напишите цикл for, который выводить в консоль числа от 65 до 15 с шагом 5 

// for(let i = 65; i >= 15; i -= 5) {
//   console.log(i)
// }


// В программе заданы две переменные n и m с числовым значением каждая. Число n больше числа m. Напишите цикл, который выводит в консоль все четные числа от m до n. 

// function getNums(n, m) {
//   for(let i = m; i <= n; i++){
//     if(i % 2 === 0){
//       console.log(i)
//     }
//   }
// }

// const getNums_arrow = (n, m) => {
//   for(let i = m; i <= n; i++){
//     if(i % 2 === 0){
//       console.log(i)
//     }
//   }
// }

// getNums_arrow(10, 4);



// В программе заданы две переменные n и m с числовым значением каждая. Напишите цикл, который выводит в консоль числа от большего числа до меньшего. Если числа равны, то вывести сообщение "The numbers are equal"

// const getNums_2 = (n, m) => {
//   if(n > m) {
//     for(let i = n; i >= m; i--){
//       console.log(i)
//     }
//   } else if (m > n) {
//     for(let i = m; i >= n; i--){
//       console.log(i)
//     }
//   } else {
//     console.log('The numbers are equal')
//   }
// }


// const getNums_3 = (n, m) => {
//   if(n === m){
//     console.log('The numbers are equal')
//     return
//   }

//   for(let i = Math.max(n, m); i >= Math.min(n, m); i--){
//     console.log(i)
//   }
// }

// getNums_3(16, 9);



// Напишите программу, которая с помощью цикла считает сумму чисел от 1 до 10 и выводит в консоль.

const getSum = () => {
  let sum = 0;
  for(let i = 1; i <= 10; i++){
    sum += i 
  }
  return sum
}


const getMult = () => {
  let result = 1;
  for(let i = 1; i <= 10; i++){
    result *= i 
  }
  return result
}




// Напишите программу, которая с помощью цикла считает сумму четных чисел от 1 до 10 и выводит в консоль => 30

const getSum1 = () => {
  let sum = 0
  for(let i = 1; i <= 10; i++){
    if(i % 2 === 0){
      sum += i
    }
  }
  return sum
}

console.log(getSum1());
