// 1. Напишите функцию, которая принимает в качестве аргумента имя (строку), а возвращает сообщение в формате: Dear ИМЯ, welcome. Выведите результат в консоль. Запишите функцию в двух форматах (function declaration и arrow function).

function getMessage(name) {
  return `Dear ${name}, welcome`
}

const getMessage_arrow = name => `Dear ${name}, welcome`;


//Напишите функцию, которая принимает в качестве аргументов два значения: имя и возраст. Если переданный возраст меньше 18, то функция возвращает сообщение в формате: Dear ИМЯ, you are younger than 18. Если возраст больше или равен 18, то функция возвращает сообщение в формате: Dear ИМЯ, you are adult. 
// Запишите функцию в двух форматах (function declaration и arrow function).

function getMessage1(name, age) {
  if (age < 18) {
    return `Dear ${name}, you are younger than 18`
  } else {
    return `Dear ${name}, you are adult`
  }
}

const getMessage1_arrow = (name, age) => {
  if (age < 18) {
    return `Dear ${name}, you are younger than 18`
  } else {
    return `Dear ${name}, you are adult`
  }
}


// У1 ? У1 верно : У1 неверно - тернарный оператор

const getMessage1_tern = (name, age) => age < 18 ? `Dear ${name}, you are younger than 18` : `Dear ${name}, you are adult`;



// 3. Напишите функцию, которая принимает два числовых аргумента и возвращает результат их умножения. Значение второго аргумента должно быть указано по умолчанию 2. Запишите функцию в двух форматах (function declaration и arrow function).

function getMultiplication(num1, num2 = 2) {
  return num1 * num2
}

const getMultiplication_arrow = (num1, num2 = 2) => num1 * num2;


// Напишите функцию, которая принимает два аргумента с числовым значением и возвращает меньшее значение. Выведите результат в консоль. Предложите два варианта решения. Запишите функцию в двух форматах (function declaration и arrow function).

function getMinNum(num1, num2) {
  return Math.min(num1, num2)
}

const getMinNum_arrow = (num1, num2) => Math.min(num1, num2);


