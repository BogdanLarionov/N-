const cards_container = document.querySelector('.cards_container');

fetch('https://reqres.in/api/users') // отправляем запрос
  .then(resp => resp.json()) // получаем ответ, преобразовываем в json
  .then(json => render(json.data)) // получаем json, что-то делаем с json

//json.data => json_data (переменная, может быть любое название)
const render = (json_data) => {
  json_data.forEach(({ first_name, email, avatar }) => {
    const card = document.createElement('div');
    const avatarElem = document.createElement('img');
    const firstnameElem = document.createElement('p');
    const emailElem = document.createElement('a');

    firstnameElem.innerText = first_name;
    emailElem.innerText = email;

    emailElem.classList.add('email_elem');
    card.classList.add('card');

    avatarElem.src = avatar;
    avatarElem.alt = 'avatar';
    emailElem.href = `mailto:${email}`;

    // avatarElem.setAttribute('src', el.avatar);
    // avatarElem.setAttribute('alt', 'avatar');
    // avatarElem.setAttribute('href', `mailto:${el.email}`);

    card.append(avatarElem, emailElem, firstnameElem);
    cards_container.append(card);
  })
}

