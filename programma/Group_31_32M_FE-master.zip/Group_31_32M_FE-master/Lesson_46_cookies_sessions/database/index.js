import mongoose from "mongoose";
import { user_data } from "./password";

mongoose.connect(`mongodb+srv://${user_data}@cluster0.rx1zuu1.mongodb.net/?retryWrites=true&w=majority&dbName=registered`)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log(err))
