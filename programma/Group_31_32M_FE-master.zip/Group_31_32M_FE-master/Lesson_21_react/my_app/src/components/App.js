import Example from "./Example";

function App() {
  return (
    <div>
      <Example first_name='Oleg' last_name='Petrov' />
      <Example first_name='Anna' last_name='Ivanova' />
      <Example first_name='Irina' last_name='Sidorova' />
    </div>
  );
}

export default App;
