import React from 'react'

export default function Example({ first_name, last_name }) {
  return (
    <div>
      <p>Firstname: {first_name}</p>
      <p>Lastname: {last_name}</p>
    </div>
  )
}
