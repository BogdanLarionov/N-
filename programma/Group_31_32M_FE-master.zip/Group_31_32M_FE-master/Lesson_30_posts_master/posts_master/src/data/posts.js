export const posts_data = [
  {
    id: 1,
    title: 'About bikes',
    text: 'Detailed information about bikes',
    like: false,
    comments: [
      {
        id: 1,
        comment: 'Good point'
      },
      {
        id: 2,
        comment: 'I disagree'
      },
      {
        id: 3,
        comment: 'Fine'
      }
    ]
  },
  {
    id: 2,
    title: 'About weather',
    text: 'Weather is good today',
    like: false,
    comments: []
  },
  {
    id: 3,
    title: 'About university',
    text: 'I hate my classes!',
    like: false,
    comments: []
  },
  {
    id: 4,
    title: 'About children',
    text: 'I love my children',
    like: false,
    comments: []
  }
]
