export const mobilesList = [
  {
    id: 1,
    mobile: 'iPhone 14',
    color: 'gray',
    quantity: 2
  },
  {
    id: 2,
    mobile: 'Samsung A53',
    color: 'white',
    quantity: 4
  },
  {
    id: 3,
    mobile: 'Huawei SN1',
    color: 'black',
    quantity: 1
  },
  {
    id: 4,
    mobile: 'iPhone 10',
    color: 'darkgreen',
    quantity: 6
  }
];
