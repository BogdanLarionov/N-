export const storesList = [
  {
    id: 1, 
    store: "Mobile center",
    distance: 1.5
  },
  {
    id: 2, 
    store: "Mobile center",
    distance: 6
  },
  {
    id: 3, 
    store: "Media markt",
    distance: 2
  },
  {
    id: 4, 
    store: "Tech point",
    distance: 0.5
  },
  {
    id: 5, 
    store: "Tech pointr",
    distance: 7
  },
  {
    id: 6, 
    store: "Mobile center",
    distance: 10.5
  }
];
