export const users = [
  {
    id: 1,
    firstname: 'Oleg',
    lastname: 'Petrov',
    address: 'Moscow, Russia',
    salary: 280,
    tasks: [
      {
        id: 1,
        task: 'Купить молоко'
      },
      {
        id: 2,
        task: 'Сделать стирку'
      }
    ]
  },
  {
    id: 2,
    firstname: 'Anna',
    lastname: 'Ivanova',
    address: 'Berlin, Germany',
    salary: 500,
    tasks: []
  },
  {
    id: 3,
    firstname: 'Irina',
    lastname: 'Grishina',
    address: 'Madrid, Spain',
    salary: 1200,
    tasks: [
      {
        id: 1,
        task: 'Купить хлеб'
      },
      {
        id: 2,
        task: 'Погладить одежду'
      },
      {
        id: 3,
        task: 'Забрать документы'
      }
    ]
  }
]
