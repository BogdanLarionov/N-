export const fruits = [
  {
    id: 1,
    title: 'Apple',
    price: 350,
    country: 'Spain'
  },
  {
    id: 2,
    title: 'Banana',
    price: 550,
    country: 'Spain'
  },
  {
    id: 3,
    title: 'Lemon',
    price: 320,
    country: 'Spain'
  },
  {
    id: 4,
    title: 'Lime',
    price: 700,
    country: 'Spain'
  },
  {
    id: 5,
    title: 'Kiwi',
    price: 630,
    country: 'Spain'
  }
]
