export const vegetables = [
  {
    id: 1,
    title: 'Potato',
    price: 300,
    country: 'Germany'
  },
  {
    id: 2,
    title: 'Tomato',
    price: 500,
    country: 'Spain'
  },
  {
    id: 3,
    title: 'Carrot',
    price: 350,
    country: 'Poland'
  },
  {
    id: 4,
    title: 'Broccoli',
    price: 200,
    country: 'USA'
  },
  {
    id: 5,
    title: 'Kale',
    price: 380,
    country: 'France'
  }
]
