import React from 'react'
import FruitsContainer from '../../components/FruitsContainer'

export default function FruitsPage() {
  return (
    <div>
      <FruitsContainer />
    </div>
  )
}
