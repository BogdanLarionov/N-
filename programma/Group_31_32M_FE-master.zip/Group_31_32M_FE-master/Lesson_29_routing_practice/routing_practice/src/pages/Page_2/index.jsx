import React from 'react'

export default function Page_2() {
  return (
    <div>Page_2</div>
  )
}
