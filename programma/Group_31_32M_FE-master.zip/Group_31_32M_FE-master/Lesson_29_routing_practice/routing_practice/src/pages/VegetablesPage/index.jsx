import React from 'react'
import VegetablesContainer from '../../components/VegetablesContainer'

export default function VegetablesPage() {
  return (
    <div>
      <VegetablesContainer />
    </div>
  )
}
