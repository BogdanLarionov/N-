import React from 'react'

export default function NotFoundPage() {
  return (
    <div>Error 404 - page not found</div>
  )
}
