import Cards from "../Cards";

function App() {

  return (
    <div>
      <Cards />
    </div>
  );
}

export default App;
