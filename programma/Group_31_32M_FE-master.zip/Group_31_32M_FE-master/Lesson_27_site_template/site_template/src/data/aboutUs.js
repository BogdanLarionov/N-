export const aboutUs = [
  {
    id: 1,
    value: 90,
    title: 'Завершено крупных сделок',
    link_title: 'Все кейсы',
    link_url: 'example.com'
  },
  {
    id: 2,
    value: 90,
    title: 'Завершено крупных сделок',
    link_title: 'Все кейсы',
    link_url: 'example.com'
  },
  {
    id: 3,
    value: 90,
    title: 'Завершено крупных сделок',
    link_title: 'Все кейсы',
    link_url: 'example.com'
  },
  {
    id: 4,
    value: 90,
    title: 'Завершено крупных сделок',
    link_title: 'Все кейсы',
    link_url: 'example.com'
  }
]
