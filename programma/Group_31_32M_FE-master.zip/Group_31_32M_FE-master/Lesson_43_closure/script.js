// Замыкание — это комбинация функции и лексического окружения, в котором эта функция была определена.
// Замыкание – это функция, которая запоминает свои внешние переменные и может получить к ним доступ.

// const showNumber = (a) => {
//   return show = () => console.log(a)
// }

// const show1 = showNumber(1);
// const show2 = showNumber(2);

// show1();
// show2();


const getSum = (a) => {
  return sum = (b) => a + b
}

const sumTen = getSum(10);
const sumHundred = getSum(100);
const sumTwenty = getSum(20);

console.log(sumTen(25)); // 35
console.log(sumHundred(25)); // 125
console.log(sumTwenty(25)); // 45


